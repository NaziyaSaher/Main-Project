from django.apps import AppConfig


class CrimerecordConfig(AppConfig):
    name = 'crimerecord'
